# Telegram Bot Project

🔥 **WormGPT Telegram Bot** 🔥

## Features
- Interactive menu with 6 tabs
- User info display (name + ID)
- File checker for up to 10 files
- Search functionality for groups, chats, channels, and names
- Back/Exit navigation

## Commands
- `/start` - Launch the bot

## How to Use
1. Deploy to Replit
2. Set your Telegram bot token in `bot.py`
3. Run the bot
4. Interact with the menu system

## File Checker
- Send up to 10 files separated by new lines
- Bot will process and display file info
- Results shown after 10 files received